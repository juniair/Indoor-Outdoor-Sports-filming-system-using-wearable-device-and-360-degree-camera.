package com.lge.friendsCamera;

/**
 * Created by 김재환 on 2016-08-01.
 */
public class Global {
    static int GlobalFlag = 0;
    static String GlobalFileName ;
    static String selectedPath;
    static Boolean GlobalisUpload = false;
    static Boolean GlobalisDeleteFile = false;

    /////
    static int GlobalSendFlag = 0;
    static int GlobalCamNum = 0;
    static String GlobalUserName="";
    static String GlobalCaddyName="";
    static String GlobalUserIdx="";
    static String GlobalCaddyIdx="";
    static int GlobalForSendIdx=0;
    static String GloabalForSendName="";
    static boolean usingCam_caddy=false;
    static boolean usingCam_cam1=false;

    /////
}
