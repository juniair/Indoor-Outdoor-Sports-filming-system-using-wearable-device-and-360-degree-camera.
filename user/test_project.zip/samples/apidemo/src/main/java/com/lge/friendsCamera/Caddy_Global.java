package com.lge.friendsCamera;

/**
 * Created by 김재환 on 2016-08-08.
 */
public class Caddy_Global {
    static String CaddyIdx = "";

    static String arrayUserInfo_idx[] = new String[4];
    static String arrayUserInfo_name[] = new String[10];

    static String idx[]=new String[4];
    static String uname[]=new String[20];

    static int arrayIdx[] = new int[999];
    static String arrayIdxToString[] = new String[999];
    static String arrayName[] = new String[999];

    static int num_sum =0;

    static int GlobalCamNum=0;
}
