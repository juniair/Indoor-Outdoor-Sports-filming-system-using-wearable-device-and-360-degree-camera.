package com.juniair.calendarview.util;

import com.juniair.calendarview.model.DailySchedule;


public interface EventHandler {
    void OnItemClickListener(DailySchedule schedule);
}
