package com.crv.myapplication.util;

import com.crv.myapplication.model.DailySchedule;


public interface EventHandler {
    void OnItemClickListener(DailySchedule schedule);
}
