package com.crv.myapplication.util;

import android.support.v7.widget.PopupMenu;

public interface OnMenuItemClickListener extends PopupMenu.OnMenuItemClickListener{

}
