package com.crv.myapplication.app;

/**
 * Created by NGN_PRINT on 2016-09-24.
 */
public class Sglobal {
    public static int idx;
    public static String name;
}
