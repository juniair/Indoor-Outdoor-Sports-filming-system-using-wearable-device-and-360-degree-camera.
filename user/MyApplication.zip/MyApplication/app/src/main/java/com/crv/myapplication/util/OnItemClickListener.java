package com.crv.myapplication.util;

import android.util.Log;
import android.widget.TextView;

public interface OnItemClickListener {
    public void itemClicked(TextView textView);
}
