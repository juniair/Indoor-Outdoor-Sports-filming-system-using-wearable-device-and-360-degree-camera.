package com.crv.myapplication.app;

/**
 * Created by NGN_PRINT on 2016-07-04.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN =    "http://218.150.183.1/moons/mobile/login.php";
    public static String URL_GETINFO =  "http://218.150.183.1/moons/mobile/day_list.php";
    public static String URL_GET_LIST = "http://218.150.183.1/moons/mobile/test_day_list.php";
    public static String LIST_URL =     "http://218.150.183.1/moons/mobile/file_list.php";

}