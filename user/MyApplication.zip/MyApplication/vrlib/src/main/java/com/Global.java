package com;

/**
 * Created by NGN_PRINT on 2016-09-20.
 */
public class Global {
    public static int video_state=0;
    public static boolean isitplaying=false;
}
