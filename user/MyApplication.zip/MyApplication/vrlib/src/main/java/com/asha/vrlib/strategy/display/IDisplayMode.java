package com.asha.vrlib.strategy.display;

/**
 * Created by hzqiujiadi on 16/3/19.
 * hzqiujiadi ashqalcn@gmail.com
 */
public interface IDisplayMode {
    int getVisibleSize();
}
