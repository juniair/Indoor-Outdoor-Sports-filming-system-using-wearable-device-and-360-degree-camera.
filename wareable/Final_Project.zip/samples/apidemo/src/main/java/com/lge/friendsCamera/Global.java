package com.lge.friendsCamera;

/**
 * Created by 김재환 on 2016-07-06.
 */
public class Global {
    static int GlobalCamNum = 0;
    static String GlobalUserName="";
    //static String GlobalCaddyName="";
    static String GlobalUserIdx="";
    //static String GlobalCaddyIdx="";
}
